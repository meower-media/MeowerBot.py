# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['meowerbot']

package_data = \
{'': ['*']}

install_requires = \
['cloudlink>=0.1.7,<0.2.0', 'meower>=0.0.6,<0.0.7', 'requests>=2.28.0,<3.0.0']

setup_kwargs = {
    'name': 'meowerbot',
    'version': '0.1.1',
    'description': 'A meower bot lib for py',
    'long_description': '# MeowerBot.py\n\nA bot lib for Meower\n\n## How to use\n\n```py\n\nfrom MeowerBot import Client\n\nc = Client("Username","password",False) \n\ndef on_raw_msg(self,msg:dict):\n\n        print(f\'msg: {msg["u"]}: {msg["p"]}\')\n        if not msg["u"] == c.username:\n            if msg["u"] == "Discord":\n                msg["u"] = msg["p"].split(":")[0]\n                msg["p"] = msg["p"].split(":")[1].strip() \n            if msg["p"].startswith(f\'@{c.username}\'):   \n                c.send_msg(f\'Hello, {msg["u"]}!\')\n\nc.callback(on_raw_msg)\n\nc.start()\n```',
    'author': 'showierdata9978',
    'author_email': '68120127+showierdata9978@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
