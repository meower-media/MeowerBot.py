# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['meowerbot']

package_data = \
{'': ['*']}

install_requires = \
['cloudlink>=0.1.7,<0.2.0', 'meower>=0.0.6,<0.0.7', 'requests>=2.28.0,<3.0.0']

setup_kwargs = {
    'name': 'meowerbot',
    'version': '0.1.0',
    'description': 'A meower bot lib for py',
    'long_description': None,
    'author': 'showierdata9978',
    'author_email': '68120127+showierdata9978@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
